<?php

    function comprobarUsuario($usuarioBuscar, $passwordBuscar)
    {
        require "conexion.php";

        $conexion = connectDB();

        $consulta = $conexion->stmt_init();

        $sql = 'SELECT * FROM usuarios WHERE usuario = ?;';

        $consulta->prepare($sql);
        $consulta->bind_param('s', $usuarioBuscar);

        $consulta->execute();

        $resultado = $consulta->get_result();


        $acceso = $resultado->fetch_object();


        $user = $acceso -> usuario;
        $passwd = $acceso -> contrasenia;

        $existeUser = false;

        if($user === $usuarioBuscar && $passwd ===  $passwordBuscar)
        {
            $existeUser = true;
        }

        return $existeUser;        
    }



    function telefonosUsuario($usuarioTelefono)
    {
        require "conexion.php";

        
        $conexion = connectDB();

        
        $consulta = $conexion->stmt_init();

        
        $sql = 'SELECT * FROM telefonos WHERE usuario = ?;';
        $consulta->prepare($sql);
    
        $consulta->bind_param('s', $usuarioTelefono);
    
        $consulta->execute();
        $consulta->bind_result($telefono, $usuario);

        while($consulta->fetch())
        {
            $arrayTelefonos[]=array($telefono, $usuario);
        }
 
        

        return $arrayTelefonos;        
    }
