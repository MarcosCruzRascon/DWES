<html>
     <head>
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
          <title>Login</title>
     </head>
     <body>
     <form name="input" action="valido.inc.php" method="post">
          Usuario:
          <input type="text" name="usuario"/><br />
          Contraseña:
          <input type="text" name="contrasenia"/><br />
          <input type="submit" value="Enviar" name="enviar"/>
     </body>
</html>