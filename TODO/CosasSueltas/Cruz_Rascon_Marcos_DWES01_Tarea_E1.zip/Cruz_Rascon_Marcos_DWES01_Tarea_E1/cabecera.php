<html>
<style>
    li {
        display: inline;
    }

    a {
        background-color: #4CAF50;
        border: none;
        color: blanco;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
    }
</style>

<body>
    <p>
        <ul>
            <li><a href="formulario.php">Formulario vacio</a></li>
            <li><a href="formulario.php?nombre=Marcos+Cruz+Rasc%C3%B3n&email=marcoscruzrascon%40gmail.com&telefono=617772169&webPreferida=https%3A%2F%2Ftwitch.com&fechaNacimiento=1997-03-31&sexo=hombre&modulos1%5B%5D=programacion&modulos1%5B%5D=entornos&modulos1%5B%5D=sistemas&modulos2%5B%5D=DWES&html=7&mysql=8&ingles=6&php=3&js=5&experiencia=Montaje+de+pc%0D%0AReparacion+de+pc%0D%0AInstalacion+de+servidores%0D%0A&sueldoActual=1250&sueldoDeseado=2600">Formulario relleno real</a></li>
            <li><a href="formulario.php?nombre=Periquillo+de+los+Palotes&email=ggwpmybro%40pepetron.com&telefono=666666666&webPreferida=https%3A%2F%2Fdiablo.com&fechaNacimiento=1666-06-06&sexo=mujer&modulos1%5B%5D=programacion&modulos2%5B%5D=DWES&modulos2%5B%5D=DIWEB&html=10&mysql=10&ingles=10&php=10&js=10&experiencia=Torturas%0D%0ACastigos%0D%0A&sueldoActual=2500&sueldoDeseado=6666">Formulario relleno irreal</a></li>
            <li><a href="formulario.php?nombre=Marcos1+Cruz+Rascon&email=marcoscruzrascon%40gmailcom&telefono=617772169&webPreferida=https%3A%2F%2Fwww.twitch.com&fechaNacimiento=&sexo=hombre&modulos1%5B%5D=programacion&modulos2%5B%5D=DWES&modulos2%5B%5D=DIWEB&modulos2%5B%5D=DWEC&html=6&mysql=6&ingles=6&php=6&js=6&experiencia=&sueldoActual=1234h&sueldoDeseado=2356&enviar=Enviar">Formulario erroneo 1</a></li>
            <li><a href="formulario.php?nombre=Marcos+Cruz+Rascon&email=marcoscruzrascon%40gmail.com&telefono=6177721&webPreferida=twitch.com&fechaNacimiento=1997-03-31&sexo=hombre&modulos2%5B%5D=DWES&modulos2%5B%5D=DIWEB&modulos2%5B%5D=DWEC&html=6&mysql=6&ingles=6&php=6&js=6&experiencia=&sueldoActual=1234&sueldoDeseado=2356&enviar=Enviar">Formulario erroneo2</a></li>
        </ul>
    </p>
</body>

</html>